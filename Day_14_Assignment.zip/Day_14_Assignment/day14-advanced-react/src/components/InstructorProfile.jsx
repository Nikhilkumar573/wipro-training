import React from "react";
export default function InstructorProfile() {
  return (
    <div className="p-3 border rounded mt-3 bg-light">
      <h5>Instructor : John Doe</h5>
      <p>Experience : 5 years in Full Stack Development</p>
    </div>
  );
}
